﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.ModelBinding;
using System.Web.UI;
using WebForms45.Model;

namespace WebForms45
{
    public partial class GridViewModelBound : System.Web.UI.Page
    {
        private Northwind _db = new Northwind();

        // <asp:GridView ID="categoriesGrid" SelectMethod="GetCategories" />
        

        // <asp:GridView ID="categoriesGrid" UpdateMethod="UpdateCategory" />
        

        // <asp:GridView ID="productsGrid" SelectMethod="GetProducts" />
        
    }
}