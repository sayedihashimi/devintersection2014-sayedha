﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace WebForms45.Controls
{
    public class MyLabel : Label
    {
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            Text = "My awesome label!";
            CssClass = "tag-mapped";
        }
    }
}