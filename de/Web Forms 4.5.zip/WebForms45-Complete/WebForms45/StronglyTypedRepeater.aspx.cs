﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebForms45.Model;

namespace WebForms45
{
    public partial class StronglyTypedRepeater : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Bind repeater
            using (var db = new Northwind())
            {
                productsRepeater.DataSource = db.Products.ToList();
                productsRepeater.DataBind();
            }
        }
    }
}