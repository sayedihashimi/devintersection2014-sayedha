﻿using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;

namespace WebForms45
{
    public partial class Async : System.Web.UI.Page
    {
        private string _url;
        private string _filePath;

        protected void load_Click(object sender, EventArgs e)
        {
            var value = url.Text;
            if (!String.IsNullOrEmpty(value) && VirtualPathUtility.IsAppRelative(value))
            {
                _filePath = value;
            }
            else if (!String.IsNullOrEmpty(value) && Uri.IsWellFormedUriString(value, UriKind.Absolute))
            {
                _url = value;
            }
            else
            {
                // No value provided
                Response.Redirect("~/Async.aspx", true);
            }

            if (!String.IsNullOrEmpty(_url) || !String.IsNullOrEmpty(_filePath))
            {
                results.Visible = true;
                RegisterAsyncTask(new PageAsyncTask(async (o, a, ct) =>
                {
                    fileContents.Text = String.Format("Started on thread {0}", Thread.CurrentThread.ManagedThreadId) + Environment.NewLine + Environment.NewLine;
                    fileContents.Text += await GetContentsAsync() + Environment.NewLine + Environment.NewLine;
                    fileContents.Text += String.Format("Ended on thread {0}", Thread.CurrentThread.ManagedThreadId);
                }));
            }
        }

        // Page_PreRenderCompleteAsync
        //protected async Task Page_PreRenderCompleteAsync(CancellationToken token)
        //{
        //    gv.DataSource = await someAsync();
        //    gv.DataBind();
        //}

        private Task<string> GetContentsAsync()
        {
            return !String.IsNullOrEmpty(_url)
                ? GetHtmlAsync(_url)
                : GetFileContentsAsync(_filePath);
        }

        private Task<string> GetHtmlAsync(string url)
        {
            using (var wc = new WebClient())
            {
                return wc.DownloadStringTaskAsync(url);
            }
        }

        private async Task<string> GetFileContentsAsync(string virtualPath)
        {
            using (var sr = new StreamReader(Server.MapPath(virtualPath)))
            {
                return await sr.ReadToEndAsync();
            }
        }
    }
}