﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Web.ModelBinding;
using System.Web.UI;
using WebForms45.Model;

namespace WebForms45
{
    public partial class GridViewModelBound : System.Web.UI.Page
    {
        private Northwind _db = new Northwind();

        // <asp:GridView ID="categoriesGrid" SelectMethod="GetCategories" />
        public IQueryable<Category> GetCategories([Control] int? minProductsCount)
        {
            var query =_db.Categories
                .Include(c => c.Products);
            
            if (minProductsCount.HasValue)
            {
                query = query.Where(c => c.Products.Count >= minProductsCount);
            }

            return query;
        }

        // <asp:GridView ID="categoriesGrid" UpdateMethod="UpdateCategory" />
        public void UpdateCategory(int categoryID)
        {
            var category = _db.Categories.Find(categoryID);
            TryUpdateModel(category);
            if (ModelState.IsValid)
            {
                // Handle unique key violation on Category name
                try
                {
                    _db.SaveChanges();
                }
                catch (DbUpdateException ex)
                {
                    var sqlEx = ex.GetBaseException() as SqlException;
                    if (sqlEx != null && sqlEx.Number == 2601 && sqlEx.Message.Contains("CategoryName"))
                    {
                        ModelState.AddModelError("CategoryName", String.Format("A category with the name {0} already exists.", category.CategoryName));
                        return;
                    }
                    throw;
                }
            }
        }

        // <asp:GridView ID="productsGrid" SelectMethod="GetProducts" />
        public IEnumerable<Product> GetProducts([Control("categoriesGrid")]int? categoryID)
        {
            return _db.Products.Where(p => p.CategoryID == categoryID);
        }
    }
}