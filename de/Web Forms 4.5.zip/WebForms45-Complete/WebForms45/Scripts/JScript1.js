﻿function foo(foo) {
    /// <signature>
    ///     <summary>Description</summary>
    /// </signature>
    /// <signature>
    ///     <summary>Description</summary>
    ///     <param name="foor" type="String">Description</param>
    /// </signature>

}

function Foo() {
    /// <summary>This is the Foo constructor</summary>
    
}
/// <field name="a" type="Object">This is A</field>
Foo.prototype.a = {};

function Bar() {
    /// <summary>This is the Bar constructor</summary>
}
Bar.prototype = new Foo();

var bar = new Bar();
