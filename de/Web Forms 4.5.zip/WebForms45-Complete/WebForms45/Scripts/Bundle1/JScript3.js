﻿/// <reference path="JScript1.js" />
/// <reference path="JScript2.js" />
function foo3(p1, p2) {
    /// <summary>foo3 function</summary>
    /// <param name="p1" type="String">This is p1</param>
    /// <param name="p2" type="String">This is p2</param>
    var myObject = {
        bar: /* block comments too! */function () {
            return this;
        }
    };
}