﻿/// <reference path="JScript2.js" />
/// <reference path="JScript3.js" />
function foo1() {
    /// <summary>foo1 function</summary>
    
}