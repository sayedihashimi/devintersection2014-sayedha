﻿/// <reference path="JScript1.js" />
/// <reference path="JScript3.js" />
function foo2() {
    /// <summary>foo2 function</summary>
    
}