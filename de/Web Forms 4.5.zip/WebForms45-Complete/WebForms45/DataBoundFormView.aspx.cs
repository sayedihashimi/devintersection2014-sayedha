﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebForms45
{
    public partial class DataBoundFormView : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }































        protected void fvDataBinding_OnItemUpdated(object sender, FormViewUpdatedEventArgs e)
        {
            if (e.Exception != null && e.Exception is ApplicationException)
            {
                e.KeepInEditMode = true;
                e.ExceptionHandled = true;
                // Show the error message somewhere

            }
        }
    }
}