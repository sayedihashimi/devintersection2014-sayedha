﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebForms45
{
    public partial class RequestValidation : System.Web.UI.Page
    {
        protected void save_Click(object sender, EventArgs e)
        {
            name.Text = "";
            description.Text = "";
            result.Text = "Item Saved!";
        }
    }
}