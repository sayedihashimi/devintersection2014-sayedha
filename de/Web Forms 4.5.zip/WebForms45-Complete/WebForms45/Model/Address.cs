﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebForms45.Model
{
    public class Address
    {
        [Key]
        public int ID { get; set; }

        [StringLength(100)]
        public string StreetLine1 { get; set; }

        [StringLength(100)]
        public string StreetLine2 { get; set; }

        [StringLength(100)]
        public string StreetLine3 { get; set; }

        [Required, StringLength(100)]
        public string City { get; set; }

        [StringLength(100)]
        public string State { get; set; }

        [StringLength(32)]
        public string ZipCode { get; set; }

        [StringLength(100)]
        public string Country { get; set; }
    }
}