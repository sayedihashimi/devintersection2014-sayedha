﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebForms45.Model
{
    public class CustomerRepository
    {
        CustomerContext _db = new CustomerContext();

        public Customer GetCustomer()
        {
            return GetCustomer(null);
        }

        public Customer GetCustomer(int? id)
        {
            var customer = _db.Customers.SingleOrDefault(c => c.ID == (id ?? 1));
            return customer;
        }

        public int SaveCustomer(Customer customer)
        {
            // Perform custom validation
            if (customer.FirstName == "Scott")
            {
                throw new ApplicationException("Scott is a funny name");
            }

            _db.Entry(customer).State = System.Data.EntityState.Modified;
            var rowsAffected = _db.SaveChanges();
            return rowsAffected;
        }
    }
}