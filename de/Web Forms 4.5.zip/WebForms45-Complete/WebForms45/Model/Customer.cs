﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebForms45.Model
{
    public class Customer
    {
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter a value for First Name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter a value for Last Name")]
        public string LastName { get; set; }

        [Range(0, 130, ErrorMessage = "Please enter a value for Age between 0 and 130")]
        public int Age { get; set; }

        public Address HomeAddress { get; set; }

        public Address BillingAddress { get; set; }

        public virtual ICollection<Address> ShippingAddresses { get; set; }

        public Address DefaultShippingAddress { get; set; }

        [DataType(DataType.PhoneNumber)]
        public string DaytimePhone { get; set; }

        [DataType(DataType.EmailAddress), StringLength(256)]
        public string EmailAddress { get; set; }
    }
}